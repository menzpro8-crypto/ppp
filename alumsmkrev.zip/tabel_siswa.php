<?php
// tabel_siswa.php (Tampilan Semua Data Alumni dari Database)
session_start();
// Memastikan koneksi database dan file layout di-include
include('koneksi.php'); 
include('header.php'); 

// Pengecekan Akses (Disarankan: hanya yang sudah login yang bisa melihat)
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

include('menu.php'); // Menu navigasi

// Query untuk mengambil data alumni lengkap
// ASUMSI: Nama tabel adalah 'alumni', dan kolomnya mencakup yang berikut.
$sql = "SELECT nisn, nama, jenis_kelamin, tahun_lulus, jurusan, status_terkini FROM alumni ORDER BY tahun_lulus DESC, nama ASC";
$result = mysqli_query($conn, $sql);

// Cek apakah ada data yang diambil
$has_data = mysqli_num_rows($result) > 0;
?>

<style>
    /* Styling Konten Umum */
    .container-alumni {
        max-width: 1200px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }
    h2 {
        color: #4BA1CF;
        border-bottom: 2px solid #eee;
        padding-bottom: 10px;
        margin-bottom: 20px;
        text-align: center;
    }
    
    /* Styling Tabel Responsif */
    .table-responsive {
        overflow-x: auto; /* Penting agar tabel tidak merusak layout di layar kecil */
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        font-size: 14px;
    }
    table th, table td {
        padding: 12px 15px;
        border: 1px solid #ddd;
        text-align: left;
        white-space: nowrap; /* Mencegah teks terpotong */
    }
    table th {
        background-color: #4BA1CF; /* Warna Biru Tema */
        color: white;
        text-transform: uppercase;
        font-size: 12px;
    }
    table tr:nth-child(even) {
        background-color: #f9f9f9;
    }
    table tr:hover {
        background-color: #f1f1f1;
    }
    .no-data {
        padding: 20px;
        text-align: center;
        color: #888;
        background-color: #f0f0f0;
        border-radius: 5px;
    }
    
    /* Styling Status Badge */
    .status-badge {
        display: inline-block;
        padding: 4px 8px;
        border-radius: 12px;
        font-size: 12px;
        font-weight: bold;
        color: white;
    }
    .status-Kuliah { background-color: #ff6384; } 
    .status-Kerja { background-color: #28a745; } /* Hijau */
    .status-Wiraswasta { background-color: #007bff; }
    .status-BelumBekerja { background-color: #ffc107; }
    .status-BelumMelengkapi { background-color: #6c757d; }
</style>

<div class="container-alumni">
    <h2>Tabel Data Alumni SMK AL-BASTHOMI</h2>

    <?php if ($has_data): ?>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>NISN/ID</th>
                    <th>Nama Lengkap</th>
                    <th>JK</th>
                    <th>Jurusan</th>
                    <th>Tahun Lulus</th>
                    <th>Status Terkini</th>
                    <th>Telepon</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)): 
                    // Tentukan kelas CSS untuk badge status
                    $status_raw = $row['status_terkini'] ?? 'Belum Melengkapi';
                    // Hilangkan spasi untuk mencocokkan nama kelas CSS
                    $status_key = str_replace(' ', '', $status_raw); 
                ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo htmlspecialchars($row['nisn']); ?></td>
                    <td><?php echo htmlspecialchars($row['nama']); ?></td>
                    <td><?php echo htmlspecialchars($row['jenis_kelamin'] ?? '-'); ?></td>
                    <td><?php echo htmlspecialchars($row['jurusan'] ?? '-'); ?></td>
                    <td><?php echo htmlspecialchars($row['tahun_lulus']); ?></td>
                    <td>
                        <span class="status-badge status-<?php echo $status_key; ?>">
                            <?php echo htmlspecialchars($status_raw); ?>
                        </span>
                    </td>
                    <td><?php echo htmlspecialchars($row['telepon'] ?? '-'); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <p class="no-data">Data alumni masih kosong atau gagal terhubung ke database. Cek koneksi Anda di `koneksi.php`.</p>
    <?php endif; ?>

</div>

<?php
include('footer.php');
// Tutup koneksi setelah selesai
mysqli_close($conn); 
?>