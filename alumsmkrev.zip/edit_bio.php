<?php
// edit_bio.php (Revisi: Mengedit data di tabel 'alumni' dan password di tabel 'akun')
session_start();
include('koneksi.php'); 
include('header.php'); 

// =======================================================
// 1. CEK STATUS LOGIN
// =======================================================
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'alumni') {
    // Pastikan hanya alumni yang bisa mengakses
    header("Location: login.php");
    exit;
}

include('menu.php'); // Include menu horizontal untuk alumni

$current_nisn = $_SESSION['username']; // NISN alumni digunakan sebagai username
$pesan = ''; // Variabel untuk pesan sukses/error
$data_alumni = null;

// =======================================================
// 2. AMBIL DATA ALUMNI SAAT INI (Tabel: alumni)
// =======================================================
$sql_alumni = "SELECT * FROM alumni WHERE nisn = ?";
$stmt_alumni = mysqli_prepare($conn, $sql_alumni);
mysqli_stmt_bind_param($stmt_alumni, "s", $current_nisn);
mysqli_stmt_execute($stmt_alumni);
$result_alumni = mysqli_stmt_get_result($stmt_alumni);

if (mysqli_num_rows($result_alumni) === 1) {
    $data_alumni = mysqli_fetch_assoc($result_alumni);
} else {
    // Jika data alumni tidak ditemukan (walaupun sudah login)
    $pesan = "<p class='error'>Data alumni tidak ditemukan.</p>";
}
mysqli_stmt_close($stmt_alumni);


// =======================================================
// 3. PROSES UPDATE DATA (POST REQUEST)
// =======================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && $data_alumni) {
    
    // Data Alumni yang bisa diubah
    $new_no_hp      = mysqli_real_escape_string($conn, $_POST['no_hp']);
    $new_alamat     = mysqli_real_escape_string($conn, $_POST['alamat']);
    $new_status     = mysqli_real_escape_string($conn, $_POST['status_saat_ini']);
    
    // Data Akun (opsional)
    $new_password = $_POST['password'] ?? '';
    $konfirmasi_password = $_POST['konfirmasi_password'] ?? '';
    
    $update_success = true;

    // --- A. Update Data Alumni (Tabel: alumni) ---
    $sql_update_alumni = "UPDATE alumni SET no_hp = ?, alamat = ?, status_saat_ini = ? WHERE nisn = ?";
    $stmt_update_alumni = mysqli_prepare($conn, $sql_update_alumni);
    mysqli_stmt_bind_param($stmt_update_alumni, "ssss", 
        $new_no_hp, 
        $new_alamat, 
        $new_status, 
        $current_nisn
    );

    if (!mysqli_stmt_execute($stmt_update_alumni)) {
        $pesan .= "<p class='error'>Gagal mengupdate data alumni: " . mysqli_error($conn) . "</p>";
        $update_success = false;
    }
    mysqli_stmt_close($stmt_update_alumni);

    // --- B. Update Password (Tabel: alumni) - Opsional ---
    if (!empty($new_password)) {
        if ($new_password !== $konfirmasi_password) {
            $pesan .= "<p class='error'>Konfirmasi password tidak cocok! Password tidak diubah.</p>";
            $update_success = false;
        } else {
            // Asumsi: Password disimpan dalam plain text di tabel 'alumni'
            $sql_update_pass = "UPDATE alumni SET password = ? WHERE nisn = ?";
            $stmt_update_pass = mysqli_prepare($conn, $sql_update_pass);
            mysqli_stmt_bind_param($stmt_update_pass, "ss", $new_password, $current_nisn);

            if (!mysqli_stmt_execute($stmt_update_pass)) {
                 $pesan .= "<p class='error'>Gagal mengupdate password: " . mysqli_error($conn) . "</p>";
                 $update_success = false;
            }
            mysqli_stmt_close($stmt_update_pass);
        }
    }
    
    // --- C. Refresh Data Alumni dan Tampilkan Pesan ---
    if ($update_success) {
        // Ambil ulang data terbaru setelah update berhasil
        $stmt_alumni_refresh = mysqli_prepare($conn, $sql_alumni);
        mysqli_stmt_bind_param($stmt_alumni_refresh, "s", $current_nisn);
        mysqli_stmt_execute($stmt_alumni_refresh);
        $result_alumni_refresh = mysqli_stmt_get_result($stmt_alumni_refresh);
        $data_alumni = mysqli_fetch_assoc($result_alumni_refresh);
        mysqli_stmt_close($stmt_alumni_refresh);

        $pesan = "<p class='success'>Data Berhasil Diperbarui!</p>";
        // Perbarui data sesi (Nama mungkin tidak diubah, tapi ini untuk praktik yang baik)
        $_SESSION['nama'] = $data_alumni['nama']; 
    }
}
?>

<style>
/* Styling Tambahan untuk Edit Form */
.edit-container {
    max-width: 600px;
    margin: 30px auto;
    padding: 30px;
    background-color: #ffffff;
    border-radius: 12px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
}

.edit-container h2 {
    text-align: center;
    color: #4BA1CF;
    margin-bottom: 25px;
    font-size: 24px;
    border-bottom: 1px solid #eee;
    padding-bottom: 10px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    font-weight: 600;
    color: #3f4257;
}

.edit-container input[type="text"],
.edit-container input[type="password"],
.edit-container textarea,
.edit-container select {
    width: 100%;
    padding: 12px;
    border: 1px solid #ccc;
    border-radius: 6px;
    box-sizing: border-box;
    font-size: 16px;
    transition: border-color 0.3s;
}

.edit-container input:focus,
.edit-container textarea:focus,
.edit-container select:focus {
    border-color: #4BA1CF;
    outline: none;
    box-shadow: 0 0 5px rgba(75, 161, 207, 0.5);
}

/* Field yang tidak bisa diubah */
.edit-container input[readonly] {
    background-color: #f5f7fa;
    color: #888;
    cursor: not-allowed;
}

.edit-container button {
    width: 100%;
    padding: 12px;
    background-color: #28a745; /* Ganti warna agar beda dengan header */
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    transition: background-color 0.3s;
    margin-top: 10px;
}

.edit-container button:hover {
    background-color: #1e7e34;
}

/* Pesan Sukses/Error */
.error, .success {
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 8px;
    text-align: center;
    font-weight: bold;
}

.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}
</style>

<div class="edit-container">
    <h2>✏️ Edit Data Diri & Akun Alumni</h2>

    <?php echo $pesan; // Tampilkan pesan sukses/error ?>

    <?php if ($data_alumni): ?>
    <form action="edit_bio.php" method="POST">
        
        <div class="form-group">
            <label for="nisn">NISN (Username):</label>
            <input type="text" id="nisn" name="nisn" 
                   value="<?php echo htmlspecialchars($data_alumni['nisn']); ?>" readonly>
        </div>

        <div class="form-group">
            <label for="nama">Nama Lengkap:</label>
            <input type="text" id="nama" name="nama" 
                   value="<?php echo htmlspecialchars($data_alumni['nama']); ?>" readonly>
        </div>
        
        <div class="form-group">
            <label for="jurusan">Jurusan:</label>
            <input type="text" id="jurusan" name="jurusan" 
                   value="<?php echo htmlspecialchars($data_alumni['jurusan']); ?>" readonly>
        </div>
        
        <hr style="margin: 25px 0;">
        
        <div class="form-group">
            <label for="no_hp">Nomor HP / WhatsApp:</label>
            <input type="text" id="no_hp" name="no_hp" placeholder="Contoh: 081234567890" 
                   value="<?php echo htmlspecialchars($data_alumni['no_hp']); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="alamat">Alamat Lengkap:</label>
            <textarea id="alamat" name="alamat" rows="3" placeholder="Masukkan alamat lengkap Anda" required><?php echo htmlspecialchars($data_alumni['alamat']); ?></textarea>
        </div>

        <div class="form-group">
            <label for="status_saat_ini">Status Saat Ini:</label>
            <select id="status_saat_ini" name="status_saat_ini" required>
                <option value="">-- Pilih Status --</option>
                <?php 
                $current_status = $data_alumni['status_saat_ini'];
                $status_options = ['Bekerja', 'Kuliah', 'Lainnya'];
                foreach ($status_options as $option) {
                    $selected = ($current_status == $option) ? 'selected' : '';
                    echo "<option value='{$option}' {$selected}>{$option}</option>";
                }
                ?>
            </select>
        </div>
        
        <hr style="margin: 25px 0;">
        <h3 style="color: #4BA1CF; margin-bottom: 20px;">Ganti Password (Opsional)</h3>
        
        <div class="form-group">
            <label for="password">Password Baru:</label>
            <input type="password" id="password" name="password" 
                   placeholder="Kosongkan jika tidak ingin mengganti">
        </div>

        <div class="form-group">
            <label for="konfirmasi_password">Konfirmasi Password Baru:</label>
            <input type="password" id="konfirmasi_password" name="konfirmasi_password" 
                   placeholder="Ulangi Password Baru">
        </div>
        
        <button type="submit">Simpan Perubahan Data</button>
    </form>
    <?php endif; ?>

</div>

<?php
include('footer.php');
mysqli_close($conn); 
?>