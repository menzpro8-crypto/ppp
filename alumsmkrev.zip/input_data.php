<?php
// input_data.php
session_start();
include('koneksi.php'); // Include koneksi database
include('header.php');  // Include header

// =======================================================
// 1. CEK HAK AKSES ADMIN
// =======================================================
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); 
    exit;
}

include('menu.php'); // Include menu horizontal untuk admin

$pesan = ''; // Variabel untuk pesan sukses/error
$nisn = $nama = $password = $jenis_kelamin = $jurusan = $tahun_lulus = $no_hp = $status_saat_ini = ''; // Inisialisasi variabel

// =======================================================
// 2. LOGIKA PROSES INPUT DATA (POST REQUEST)
// =======================================================
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data dari form dan sanitasi
    $nisn            = mysqli_real_escape_string($conn, $_POST['nisn']);
    $nama            = mysqli_real_escape_string($conn, $_POST['nama']);
    $password        = mysqli_real_escape_string($conn, $_POST['password']);
    $jenis_kelamin   = mysqli_real_escape_string($conn, $_POST['jenis_kelamin']);
    $jurusan         = mysqli_real_escape_string($conn, $_POST['jurusan']);
    $tahun_lulus     = mysqli_real_escape_string($conn, $_POST['tahun_lulus']);
    $no_hp           = mysqli_real_escape_string($conn, $_POST['no_hp']);
    $status_saat_ini = mysqli_real_escape_string($conn, $_POST['status_saat_ini']); // BARU: Ambil dari form

    // Validasi sederhana: Cek NISN sudah ada atau belum
    $check_query = "SELECT nisn FROM alumni WHERE nisn = '$nisn'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $pesan = "<p class='error'>Gagal! NISN **$nisn** sudah terdaftar sebagai alumni. Data tidak dapat ditambahkan.</p>";
    } else {
        // Kolom yang digunakan: nisn, nama, password, jenis_kelamin, jurusan, tahun_lulus, no_hp, status_saat_ini
        // Kolom created_at dan updated_at akan terisi otomatis oleh MySQL.
        $sql = "INSERT INTO alumni (nisn, nama, password, jenis_kelamin, jurusan, tahun_lulus, no_hp, status_saat_ini) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        // Siapkan statement
        $stmt = mysqli_prepare($conn, $sql);
        
        // Sesuaikan bind_param (8 parameter string)
        // nisn, nama, password, j_kelamin, jurusan, tahun_lulus, no_hp, status_saat_ini
        mysqli_stmt_bind_param($stmt, "ssssssss", 
            $nisn, 
            $nama, 
            $password, 
            $jenis_kelamin, 
            $jurusan, 
            $tahun_lulus, 
            $no_hp,
            $status_saat_ini
        );

        if (mysqli_stmt_execute($stmt)) {
            $pesan = "<p class='success'>Data alumni atas nama **$nama (NISN: $nisn)** berhasil ditambahkan!</p>";
            
            // Setelah sukses, kosongkan variabel form
            $nisn = $nama = $password = $jenis_kelamin = $jurusan = $tahun_lulus = $no_hp = $status_saat_ini = '';
            
        } else {
            $pesan = "<p class='error'>Gagal menambahkan data. Error: " . mysqli_error($conn) . "</p>";
        }

        mysqli_stmt_close($stmt);
    }
}

// =======================================================
// 3. TAMPILAN FORM
// =======================================================
?>

<style>
    /* Styling Form Input Data Baru */
    .input-container {
        max-width: 700px;
        margin: 30px auto;
        padding: 30px;
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    }

    .input-container h1 {
        text-align: center;
        color: #3f4257;
        margin-bottom: 25px;
        border-bottom: 2px solid #eee;
        padding-bottom: 15px;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-group label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #555;
    }

    .form-group input[type="text"],
    .form-group input[type="number"],
    .form-group input[type="password"],
    .form-group select {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box; 
        font-size: 16px;
    }

    .form-group select {
        appearance: none; 
        background-image: url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-24.8%200l-88%2088-88-88a17.6%2017.6%200%200%200-24.8%2024.8l100%20100a17.6%2017.6%200%200%200%2024.8%200l100-100a17.6%2017.6%200%200%200%200-24.8z%22%2F%3E%3C%2Fsvg%3E');
        background-repeat: no-repeat;
        background-position: right 10px top 50%;
        background-size: 12px;
    }

    .form-group button {
        width: 100%;
        padding: 12px;
        background-color: #4BA1CF; 
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 18px;
        font-weight: bold;
        transition: background-color 0.3s;
        margin-top: 10px;
    }

    .form-group button:hover {
        background-color: #2F7BA8;
    }

    /* Styling Pesan */
    .error, .success {
        padding: 15px;
        margin-bottom: 25px;
        border-radius: 8px;
        text-align: center;
        font-weight: bold;
    }
    
    .error {
        background-color: #f8d7da;
        color: #721c24;
        border: 1px solid #f5c6cb;
    }
    
    .success {
        background-color: #d4edda;
        color: #155724;
        border: 1px solid #c3e6cb;
    }
</style>

<div class="input-container">
    <h1>Input Data Alumni Baru</h1>

    <?php echo $pesan; // Tampilkan pesan ?>

    <form action="input_data.php" method="POST">
        
        <div class="form-group">
            <label for="nisn">NISN (Nomor Induk Siswa Nasional):</label>
            <input type="number" id="nisn" name="nisn" placeholder="Masukkan NISN" 
                   value="<?php echo htmlspecialchars($nisn); ?>" required minlength="10" maxlength="10">
        </div>
        
        <div class="form-group">
            <label for="nama">Nama Lengkap:</label>
            <input type="text" id="nama" name="nama" placeholder="Masukkan Nama Lengkap" 
                   value="<?php echo htmlspecialchars($nama); ?>" required>
        </div>

        <div class="form-group">
            <label for="password">Password Awal (Untuk Login Alumni):</label>
            <input type="password" id="password" name="password" placeholder="Buat Password Awal" required>
        </div>

        <div class="form-group">
            <label for="jenis_kelamin">Jenis Kelamin:</label>
            <select id="jenis_kelamin" name="jenis_kelamin" required>
                <option value="">-- Pilih Jenis Kelamin --</option>
                <option value="Laki-laki" <?php echo $jenis_kelamin == 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option>
                <option value="Perempuan" <?php echo $jenis_kelamin == 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option>
            </select>
        </div>

        <div class="form-group">
            <label for="jurusan">Jurusan:</label>
            <select id="jurusan" name="jurusan" required>
                <option value="">-- Pilih Jurusan --</option>
                <option value="RPL" <?php echo ($jurusan ?? '') == 'rpl' ? 'selected' : ''; ?>>Rekayasa Perangkat Lunak (RPL)</option>
                <option value="TKJ" <?php echo ($jurusan ?? '') == 'mm' ? 'selected' : ''; ?>>Multi Media (MM)</option>
                <option value="TSM" <?php echo ($jurusan ?? '') == 'oto' ? 'selected' : ''; ?>>Otomotif (OTO)</option>
                <option value="TKR" <?php echo ($jurusan ?? '') == 'mesin' ? 'selected' : ''; ?>>Teknik Permerinan (TM)</option>
            </select>
        </div>
        
        <div class="form-group">
            <label for="status_saat_ini">Status Saat Ini:</label>
            <select id="status_saat_ini" name="status_saat_ini" required>
                <option value="">-- Pilih Status --</option>
                <option value="Bekerja" <?php echo $status_saat_ini == 'Bekerja' ? 'selected' : ''; ?>>Bekerja</option>
                <option value="Kuliah" <?php echo $status_saat_ini == 'Kuliah' ? 'selected' : ''; ?>>Kuliah</option>
                <option value="Lainnya" <?php echo $status_saat_ini == 'Lainnya' ? 'selected' : ''; ?>>Lainnya</option>
            </select>
        </div>
        <div class="form-group">
            <label for="tahun_lulus">Tahun Lulus:</label>
            <input type="number" id="tahun_lulus" name="tahun_lulus" placeholder="Contoh: 2023" min="2000" max="<?php echo date('Y'); ?>" 
                   value="<?php echo htmlspecialchars($tahun_lulus); ?>" required>
        </div>

        <div class="form-group">
            <label for="no_hp">Nomor HP / WhatsApp:</label>
            <input type="text" id="no_hp" name="no_hp" placeholder="Contoh: 081234567890" 
                   value="<?php echo htmlspecialchars($no_hp); ?>" required>
        </div>

        <div class="form-group">
            <button type="submit" name="submit">Simpan Data Alumni</button>
        </div>

    </form>
</div>

<?php
include('footer.php');
// Tutup koneksi database setelah selesai
mysqli_close($conn); 
?>