<?php
// jobs.php - Public listing of active job postings
include('koneksi.php');
include('header.php');
include('menu.php');

// Ambil lowongan aktif (expire_date NULL atau >= hari ini)
$sql = "SELECT id, title, company, location, description, link, expire_date, created_at FROM jobs WHERE expire_date IS NULL OR expire_date >= CURDATE() ORDER BY created_at DESC";
$res = mysqli_query($conn, $sql);
$jobs = [];
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) $jobs[] = $row;
}
?>

<style>
.container { max-width:1100px; margin:20px auto; padding:20px; background:#fff; border-radius:8px; }
.job { border-bottom:1px solid #eee; padding:12px 0 }
.job h3 { margin:0; color:#4BA1CF }
.job .meta { color:#666; font-size:13px }
.btn-apply { background:#28a745; color:#fff; padding:6px 10px; border-radius:6px; text-decoration:none }
</style>

<div class="container">
    <h2>Lowongan Kerja</h2>
    <?php if (empty($jobs)): ?>
        <p>Tidak ada lowongan pekerjaan aktif saat ini.</p>
    <?php else: ?>
        <?php foreach ($jobs as $j): ?>
            <div class="job">
                <h3><?php echo htmlspecialchars($j['title']); ?></h3>
                <div class="meta"><?php echo htmlspecialchars($j['company'] ?: '-'); ?> • <?php echo htmlspecialchars($j['location'] ?: '-'); ?> • Diposting: <?php echo htmlspecialchars(date('Y-m-d', strtotime($j['created_at']))); ?></div>
                <p><?php echo nl2br(htmlspecialchars($j['description'] ?: '')); ?></p>
                <div style="margin-top:8px;">
                    <?php if (!empty($j['link'])): ?>
                        <a class="btn-apply" href="<?php echo htmlspecialchars($j['link']); ?>" target="_blank">Lihat Detail</a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include('footer.php'); mysqli_close($conn); ?>
