<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    
    <style>
        /* Variabel Warna */
        :root {
            --primary-color: #4BA1CF; /* Warna tema dari header.php */
            --secondary-color: #2F7BA8; /* Warna turunan */
            --bg-color: #f0f0f0;
            --card-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
            --text-dark: #333;
        }

        /* Base Styling & Background Gradient */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            /* Background Gradient */
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
        }

        /* Login Container Lebih Modern */
        .login-container {
            background-color: white;
            padding: 40px;
            border-radius: 15px; /* Lebih melengkung */
            box-shadow: var(--card-shadow); /* Shadow lebih dalam */
            width: 100%;
            max-width: 400px;
            transition: transform 0.3s ease-in-out;
        }

        .login-container h2 {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 25px;
            font-size: 28px;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        
        .login-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
            color: var(--text-dark);
            font-size: 14px;
        }

        /* Inputs */
        .login-container input {
            width: 100%;
            padding: 12px 15px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-sizing: border-box;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        .login-container input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(75, 161, 207, 0.3); /* Outline lembut */
            outline: none;
        }

        /* Button */
        .login-container button {
            width: 100%;
            padding: 12px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.1s;
        }

        .login-container button:hover {
            background-color: var(--secondary-color);
            transform: translateY(-2px); /* Efek tekan */
        }
        
        /* Tautan Kembali */
        .back-link {
            display: block;
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: var(--text-dark);
        }

        .back-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        .back-link a:hover {
            color: var(--secondary-color);
            text-decoration: underline;
        }

        /* Error Message Lebih Menonjol */
        .error { 
            color: white; 
            background-color: #ff6347; 
            padding: 10px;
            border-radius: 6px;
            text-align: center; 
            margin-bottom: 15px; 
            font-weight: 600;
        }
    </style>
</head>
<body>

    <div class="login-container">
    <h2>LOGIN</h2>

    <?php
    // Menampilkan pesan error jika ada (dari proses_login.php)
    if (isset($_GET['error']) && $_GET['error'] == 1) {
        echo '<p class="error">Username atau password salah!</p>';
    }
     if (isset($_GET['error']) && $_GET['error'] == 2) {
        echo '<p class="error">Username dan Password harus diisi!</p>';
    }
    ?>

    <form action="proses_login.php" method="POST">
        <label for="username">Nama:</label>
        <input type="text" id="username" name="username" placeholder="Masukkan Nama atau Username Admin" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Masukkan Password" required>

        <button type="submit">MASUK</button>
    </form>
    
    <div class="back-link">
        <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
        <p><a href="dashboard.php">Kembali ke Dashboard Publik</a></p>
    </div>
</div>
</body>
</html>