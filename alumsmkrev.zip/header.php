<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Alumni</title>
    <style>
        body {
            /* Hapus margin: 0 dan padding: 0 di sini */
            /* Agar body dashboard bisa memiliki background color */
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif; /* Set font base */
        }
        .header {
            padding-right: 20px;
            padding-left: 20px;
            background: #4BA1CF;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1); /* Tambah shadow agar menonjol */
        }
        .logo {
            color: white;
            padding: 10px 0; /* Tambah padding vertikal */
        }
        .logo h1 {
            font-size: 28px;
            margin-bottom: 0;
        }
        .logo h2 {
            font-size: 16px;
            margin-top: 0;
        }
        .menu {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .menu a {
            text-decoration: none;
            color: white;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .menu a:hover {
            background: rgba(255, 255, 255, 0.2);
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">
            <h1>SMK AL-BASTHOMI</h1>
            <h2>LOCERET NGANJUK</h2>
        </div>
        <div class="menu">
            <?php 
            if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) { 
            
                // Tautan KHUSUS ADMIN (jika ada)
                if ($_SESSION['role'] == 'admin') {
                    // echo '<a href="kelola_data.php">KELOLA DATA</a>'; // Contoh menu khusus admin
                }
                
                // Tampilan Nama dan Logout
                echo "<span style='color: white;'>Selamat Datang, " . htmlspecialchars($_SESSION['nama']) . "</span>"; 
                echo '<a href="logout.php">LOGOUT</a>';
            } else {
                // Tautan muncul saat belum login
                echo '<a href="login.php">LOGIN</a>';
            } 
            ?>
        </div>
    </div>