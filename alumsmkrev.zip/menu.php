<?php
// menu.php
// File ini di-include di dashboard_logined.php, di bawah header.

// NOTE PENTING: Pengecekan role 'admin' dan 'alumni' di sini KRUSIAL.
// Pastikan proses_login.php menetapkan $_SESSION['role'] = 'admin' atau 'alumni'.
$role = $_SESSION['role'] ?? 'guest'; // Ambil role user

?>
<style>
/* --- CSS Menu Horizontal --- */
.menu-horizontal {
    background-color: #3f4257; /* Warna latar belakang menu (agak gelap) */
    padding: 0;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.menu-horizontal ul {
    list-style: none;
    padding: 0;
    margin: 0 auto;
    max-width: 1200px; /* Batasi lebar menu sesuai konten dashboard */
    display: flex; /* Menu ditampilkan secara horizontal */
    flex-wrap: wrap;
}

.menu-horizontal li {
    /* Hapus border vertikal lama */
}

.menu-horizontal li a {
    display: flex;
    align-items: center;
    padding: 15px 20px;
    text-decoration: none;
    color: #f5f7fa; /* Warna teks menu */
    font-weight: 600;
    transition: background-color 0.3s;
    white-space: nowrap; /* Mencegah wrap */
}

.menu-horizontal li a:hover {
    background-color: #4BA1CF; /* Warna tema saat hover */
    color: white;
}

/* Icon Sederhana */
.menu-horizontal li a span {
    margin-right: 8px;
    font-size: 16px;
}
</style>

<div class="menu-horizontal">
    <ul>
        <li>
            <a href="dashboard_logined.php">
                <span role="img" aria-label="Home">🏠</span> HOME
            </a>
        </li>
        
        <?php if ($role == 'admin'): ?>
            
            <li>
                <a href="kelola_alumni.php">
                    <span role="img" aria-label="Data">📁</span> Kelola Data Alumni
                </a>
            </li>
            <li>
                <a href="input_data.php">
                    <span role="img" aria-label="Input">➕</span> Input Data Baru
                </a>
            </li>
            <li>
                <a href="laporan.php">
                    <span role="img" aria-label="Laporan">📊</span> Laporan
                </a>
            </li>
            <li>
                <a href="jobs_admin.php">
                    <span role="img" aria-label="Lowongan">💼</span> Lowongan Kerja
                </a>
            </li>
            
        <?php endif; ?>

        <?php if ($role == 'alumni'): ?>
            
            <li>
                <a href="edit_bio.php">
                    <span role="img" aria-label="Edit">✏️</span> Edit Data Diri
                </a>
            </li>
            <?php endif; ?>
    </ul>
</div>