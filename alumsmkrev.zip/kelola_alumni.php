<?php
// kelola_alumni.php
session_start();

// Pengecekan Akses Admin
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); 
    exit;
}

include('koneksi.php'); // Include koneksi database
include('header.php');  // Include header
include('menu.php');    // Include menu horizontal untuk admin

// --- FUNGSI AMBIL SEMUA DATA ALUMNI (SESUAI ENUM BARU) ---
$alumni_data = [];
$query = "SELECT 
            `id`,
            `nisn`, 
            `nama`,
            `jenis_kelamin`,
            `tahun_lulus`, 
            `jurusan`,          /* Menggunakan Kolom Jurusan */
            `no_hp`,
            `alamat`,
            `status_saat_ini`   /* Menggunakan Kolom Status Saat Ini (Bekerja, Kuliah, Lainnya) */
          FROM `alumni` 
          ORDER BY `tahun_lulus` DESC, `nama` ASC";

$result = mysqli_query($conn, $query);

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $alumni_data[] = $row;
    }
}

// Gaya CSS untuk Tabel Admin
?>
<style>
/* Styling Tabel */
.table-container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 20px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.05);
}

.table-container h1 {
    color: #4BA1CF;
    border-bottom: 2px solid #eee;
    padding-bottom: 10px;
    margin-bottom: 20px;
}

.alumni-table {
    width: 100%;
    border-collapse: collapse;
}

.alumni-table th, .alumni-table td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #ddd;
    /* Pastikan Jurusan dan Status tidak terlalu sempit */
    white-space: nowrap; 
}

.alumni-table th {
    background-color: #4BA1CF;
    color: white;
    font-weight: 600;
}

.alumni-table tr:hover {
    background-color: #f5f5f5;
}

.action-links a {
    text-decoration: none;
    padding: 5px 10px;
    border-radius: 4px;
    margin-right: 5px;
    font-size: 14px;
    font-weight: bold;
}

.edit {
    background-color: #28a745; /* Hijau */
    color: white;
}

.hapus {
    background-color: #dc3545; /* Merah */
    color: white;
}

/* Styling untuk Status (Badge) */
.status-badge {
    padding: 5px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: bold;
    color: white;
}

/* Warna untuk ENUM status_saat_ini */
.status-Bekerja { background-color: #28a745; } 
.status-Kuliah { background-color: #007bff; }  
.status-Lainnya { background-color: #ffc107; color: #333; } 

/* Tambahan: Tombol Tambah Data */
.btn-tambah {
    display: inline-block;
    background-color: #4BA1CF; 
    color: white;
    padding: 10px 15px;
    margin-bottom: 15px;
    border-radius: 5px;
    text-decoration: none;
    font-weight: bold;
    transition: background-color 0.3s;
}

.btn-tambah:hover {
    background-color: #2F7BA8;
}

/* CSS untuk Pesan Sukses/Gagal */
.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}
</style>

<div class="table-container">
    <h1>Kelola Data Alumni</h1>
    
    <?php 
    // Menampilkan pesan dari proses hapus/edit (jika ada)
    if (isset($_GET['pesan']) && isset($_GET['msg'])) {
        $msg = htmlspecialchars(urldecode($_GET['msg']));
        $class = ($_GET['pesan'] == 'sukses') ? 'success' : 'error';
        echo "<div class='{$class}' style='padding: 10px; margin-bottom: 15px; border-radius: 5px; text-align: center;'>{$msg}</div>";
    }
    ?>

    <a href="input_data.php" class="btn-tambah">
        <span role="img" aria-label="Input">➕</span> Tambah Data Alumni
    </a>

    <?php if (empty($alumni_data)): ?>
        <p>Tidak ada data alumni yang ditemukan.</p>
    <?php else: ?>
        <div class="table-responsive" style="overflow-x: auto;">
            <table class="alumni-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nisn</th>
                        <th>Nama</th>
                        <th>gender</th>
                        <th>Lulus</th>
                        <th>Jurusan</th>            
                        <th>No. HP</th>
                        <th>alamat</th>
                        <th>Status Saat Ini</th>    
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; // Inisialisasi nomor urut ?>
                    <?php foreach ($alumni_data as $alumni): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><?php echo htmlspecialchars($alumni['nisn']); ?></td>
                            <td><?php echo htmlspecialchars($alumni['nama']); ?></td>
                            <td><?php echo htmlspecialchars($alumni['jenis_kelamin']); ?></td>
                            <td><?php echo htmlspecialchars($alumni['tahun_lulus']); ?></td>
                            <td><?php echo htmlspecialchars($alumni['jurusan']); ?></td> 
                            <td><?php echo htmlspecialchars($alumni['no_hp']); ?></td>
                            <td><?php echo htmlspecialchars($alumni['alamat']); ?></td>
                            <td><?php echo htmlspecialchars($alumni['status_saat_ini']);?></td>
                            <td class="action-links">
                                <a href="edit_alumni.php?id=<?php echo $alumni['id']; ?>" class="edit">Edit</a>
                                <a href="hapus_alumni.php?id=<?php echo $alumni['id']; ?>" class="hapus" onclick="return confirm('Anda yakin ingin menghapus data <?php echo htmlspecialchars($alumni['nama']); ?>?');">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

</div>

<?php
include('footer.php');
mysqli_close($conn); 
?>