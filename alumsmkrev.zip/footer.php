
</html><style>
    /* Style untuk Footer */
    .footer-container {
        background: #2b2d42; /* Warna gelap, serasi dengan teks dark */
        color: #f5f7fa; /* Warna teks terang */
        margin-top: 40px; /* Jarak dari konten dashboard */
        border-top: 5px solid var(--primary-color, #4BA1CF); /* Garis biru tema */
        text-align: center;
        width: 100%; /* Pastikan lebar penuh */
    }
    
    .footer-content {
        max-width: 1200px;
        margin: 0 auto;
    }

    .footer-content p {
        margin: 5px 0;
        font-size: 14px;
    }
    
    .footer-content a {
        color: #8d99ae; /* Warna abu-abu muted */
        text-decoration: none;
        transition: color 0.3s;
    }

    .footer-content a:hover {
        color: #ffffff;
    }
</style>

    <div class="footer-container">
        <div class="footer-content">
            <p><strong>SMK AL-BASTHOMI LOCERET NGANJUK</strong></p>
            <p>Sistem Monitoring Alumni | <a href="login.php">Admin Login</a></p>
            <p>&copy; <?php echo date("Y"); ?>. All Rights Reserved. Terima kasih telah mengunjungi web kami.</p>
        </div>
    </div>
    
    </body>
</html>