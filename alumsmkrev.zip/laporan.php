<?php
// laporan.php
session_start();
include('koneksi.php'); 
include('header.php'); 

// =======================================================
// 1. CEK HAK AKSES ADMIN
// =======================================================
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); 
    exit;
}

include('menu.php'); 

// =======================================================
// 2. LOGIKA EKSPOR DATA (Jika Tombol Ekspor Ditekan)
// =======================================================
if (isset($_POST['export'])) {
    // Nama file yang akan diunduh
    $filename = "Laporan_Alumni_SMK_Export_" . date('Ymd_His') . ".csv";
    
    // Set header agar browser mengunduh file
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);

    // Buat file pointer
    $output = fopen('php://output', 'w');

    // Tulis Header Kolom
    fputcsv($output, [
        'ID', 'NISN', 'Nama', 'Jenis Kelamin', 'Jurusan', 
        'Tahun Lulus', 'No HP', 'Status Saat Ini', 'Created At', 'Updated At'
    ]);
    
    // Ambil Data dari Database
    $query = "SELECT id, nisn, nama, jenis_kelamin, jurusan, tahun_lulus, no_hp, status_saat_ini, created_at, updated_at FROM alumni ORDER BY tahun_lulus DESC";
    $result = mysqli_query($conn, $query);

    // Tulis Data ke File CSV
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {
            // fputcsv otomatis menangani koma dan tanda kutip
            fputcsv($output, $row);
        }
    }

    fclose($output);
    exit; // Hentikan eksekusi script setelah ekspor
}

// =======================================================
// 3. LOGIKA UNTUK LAPORAN STATISTIK STATUS (Grafik & Tabel)
// =======================================================
$status_data = [];
$labels = ['Bekerja', 'Kuliah', 'Lainnya'];
$data_values = [0, 0, 0];
$total_alumni = 0;

$query_status = "SELECT status_saat_ini, COUNT(id) AS jumlah FROM alumni GROUP BY status_saat_ini";
$result_status = mysqli_query($conn, $query_status);

if ($result_status) {
    while ($row = mysqli_fetch_assoc($result_status)) {
        $status = $row['status_saat_ini'];
        $jumlah = (int)$row['jumlah'];
        $total_alumni += $jumlah;

        if ($status == 'Bekerja') {
            $data_values[0] = $jumlah;
        } elseif ($status == 'Kuliah') {
            $data_values[1] = $jumlah;
        } elseif ($status == 'Lainnya') {
            $data_values[2] = $jumlah;
        }
    }
}
// Untuk digunakan dalam JavaScript Chart
$labels_json = json_encode($labels);
$data_values_json = json_encode($data_values);

?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
/* Styling Laporan */
.laporan-container {
    max-width: 1200px;
    margin: 20px auto;
    padding: 30px;
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}
.laporan-container h1 {
    text-align: center;
    color: #3f4257;
    margin-bottom: 30px;
    border-bottom: 2px solid #eee;
    padding-bottom: 15px;
}
.chart-card {
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 30px;
    box-shadow: inset 0 0 10px rgba(0, 0, 0, 0.05);
}
.chart-wrapper {
    max-height: 400px;
    display: flex;
    justify-content: center;
    align-items: center;
}
.table-summary {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}
.table-summary th, .table-summary td {
    border: 1px solid #ddd;
    padding: 12px;
    text-align: left;
}
.table-summary th {
    background-color: #4BA1CF;
    color: white;
}
.table-summary tr:nth-child(even) {
    background-color: #f2f2f2;
}
.export-section {
    text-align: right;
    margin-top: 30px;
}
.export-section button {
    padding: 10px 20px;
    background-color: #28a745; /* Hijau */
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    transition: background-color 0.3s;
}
.export-section button:hover {
    background-color: #1e7e34;
}
</style>

<div class="laporan-container">
    <h1>Laporan Statistik Alumni</h1>

    <?php if ($total_alumni > 0): ?>

    <div class="chart-card">
        <h2>Distribusi Status Saat Ini (Total Alumni: <?php echo $total_alumni; ?>)</h2>
        <div class="chart-wrapper">
            <canvas id="statusPieChart" style="max-height: 350px;"></canvas>
        </div>

        <table class="table-summary">
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Jumlah Alumni</th>
                    <th>Persentase</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                foreach ($labels as $index => $label): 
                    $jumlah = $data_values[$index];
                    $persen = ($total_alumni > 0) ? round(($jumlah / $total_alumni) * 100, 2) : 0;
                ?>
                <tr>
                    <td><?php echo $label; ?></td>
                    <td><?php echo $jumlah; ?> orang</td>
                    <td><?php echo $persen; ?>%</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="export-section">
        <p>Ekspor semua data alumni ke file CSV untuk analisis lebih lanjut.</p>
        <form method="POST" action="laporan.php">
            <button type="submit" name="export">Ekspor Semua Data (.CSV)</button>
        </form>
    </div>

    <script>
        // Data dari PHP
        const labelsPie = <?php echo $labels_json; ?>;
        const dataValuesPie = <?php echo $data_values_json; ?>;
        const backgroundColors = [
            'rgba(255, 99, 132, 0.8)', // Merah untuk Bekerja (misalnya)
            'rgba(54, 162, 235, 0.8)', // Biru untuk Kuliah
            'rgba(255, 206, 86, 0.8)'  // Kuning untuk Lainnya
        ];

        // Konfigurasi Chart.js
        const configPie = {
            type: 'doughnut',
            data: {
                labels: labelsPie,
                datasets: [{
                    label: 'Jumlah Alumni',
                    data: dataValuesPie,
                    backgroundColor: backgroundColors,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '60%', 
                plugins: {
                    title: { display: false },
                    legend: { position: 'bottom' },
                }
            }
        };

        // Render Chart
        new Chart(document.getElementById('statusPieChart'), configPie);
    </script>

    <?php else: ?>
        <p style="text-align: center; color: #777;">Belum ada data alumni yang tersedia untuk membuat laporan.</p>
    <?php endif; ?>

</div>

<?php
include('footer.php');
mysqli_close($conn); 
?>