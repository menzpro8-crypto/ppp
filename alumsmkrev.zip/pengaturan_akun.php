<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || ($_SESSION['role'] ?? '') !== 'alumni') {
    header("Location: login.php");
    exit;
}

include('koneksi.php');
include('header.php');
include('menu.php');

$current_nisn = $_SESSION['username'];
$msg = isset($_GET['msg']) ? htmlspecialchars($_GET['msg']) : null;
$status = isset($_GET['status']) ? $_GET['status'] : null;

$alumni = null;
$sql = "SELECT nisn, nama, email FROM alumni WHERE nisn = ? LIMIT 1";
$stmt = mysqli_prepare($conn, $sql);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, 's', $current_nisn);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    if ($res && mysqli_num_rows($res) === 1) {
        $alumni = mysqli_fetch_assoc($res);
    }
    mysqli_stmt_close($stmt);
}

?>

<style>
/* Account settings styles (consistent with admin UI) */
:root{--accent:#4BA1CF;--muted:#6c757d;--card:#fff}
body{background:#f7f9fb}
.acct-container{max-width:900px;margin:28px auto;padding:0 16px}
.acct-card{background:var(--card);border-radius:10px;padding:20px;box-shadow:0 6px 18px rgba(31,45,61,0.06)}
.acct-card h2{margin:0 0 8px;color:#16325c}
.field{margin-bottom:12px}
.field label{display:block;font-weight:600;margin-bottom:6px}
.field input{width:100%;padding:10px;border:1px solid #e3e6ea;border-radius:8px;box-sizing:border-box}
.help{color:var(--muted);font-size:13px;margin-top:6px}
.actions{margin-top:14px}
.btn{padding:10px 14px;border-radius:8px;border:none;color:#fff;background:var(--accent);font-weight:700;cursor:pointer}
.btn-secondary{background:#6c757d}
.msg{margin-bottom:12px;padding:10px;border-radius:8px}
.msg.success{background:#d4edda;color:#155724}
.msg.error{background:#f8d7da;color:#721c24}
@media(max-width:600px){.acct-card{padding:14px}}
</style>

<div class="acct-container">
    <div class="acct-card">
        <h2>Pengaturan Akun</h2>
        <p class="help">Perbarui email atau ganti kata sandi Anda di sini. Isi "Password Lama" hanya bila mengganti password.</p>

        <?php if ($msg): ?>
            <div class="msg <?php echo $status === 'ok' ? 'success' : 'error'; ?>"><?php echo $msg; ?></div>
        <?php endif; ?>

        <?php if (!$alumni): ?>
            <div class="msg error">Data profil tidak ditemukan. Silakan hubungi admin.</div>
        <?php else: ?>
            <form id="acctForm" action="proses_pengaturan_akun.php" method="POST">
                <div class="field">
                    <label>NISN</label>
                    <input type="text" value="<?php echo htmlspecialchars($alumni['nisn']); ?>" readonly>
                </div>

                <div class="field">
                    <label>Nama</label>
                    <input type="text" value="<?php echo htmlspecialchars($alumni['nama']); ?>" readonly>
                </div>

                <div class="field">
                    <label for="email">Email</label>
                    <input id="email" name="email" type="email" value="<?php echo htmlspecialchars($alumni['email'] ?? ''); ?>" placeholder="you@example.com">
                </div>

                <hr style="margin:18px 0">

                <div class="field">
                    <label for="old_password">Password Lama</label>
                    <input id="old_password" name="old_password" type="password" placeholder="Kosongkan jika tidak mengganti password">
                </div>

                <div class="field">
                    <label for="new_password">Password Baru</label>
                    <input id="new_password" name="new_password" type="password" placeholder="Minimal 6 karakter">
                </div>

                <div class="field">
                    <label for="confirm_password">Konfirmasi Password Baru</label>
                    <input id="confirm_password" name="confirm_password" type="password" placeholder="Ulangi password baru">
                </div>

                <div class="actions">
                    <button class="btn" type="submit">Simpan Perubahan</button>
                    <a class="btn btn-secondary" href="dashboard_logined.php" style="text-decoration:none;display:inline-block;margin-left:8px;padding:10px 14px;">Batal</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
// Client-side validation: ensure new password matches confirm
document.getElementById('acctForm')?.addEventListener('submit', function(e){
    var newp = document.getElementById('new_password').value;
    var conf = document.getElementById('confirm_password').value;
    if (newp || conf) {
        if (newp.length > 0 && newp.length < 6) {
            alert('Password baru harus minimal 6 karakter.');
            e.preventDefault();
            return false;
        }
        if (newp !== conf) {
            alert('Konfirmasi password tidak cocok.');
            e.preventDefault();
            return false;
        }
        // Ensure old password provided when changing
        var oldp = document.getElementById('old_password').value;
        if (!oldp) {
            alert('Masukkan password lama untuk mengganti password.');
            e.preventDefault();
            return false;
        }
    }
});
</script>

<?php include('footer.php'); mysqli_close($conn); ?>