<?php
session_start();
// Pastikan user sudah login
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

// Data Alumni di-include jika dibutuhkan (misalnya untuk mengambil data nama)
// include('data_alumni.php'); 
?>
<?php
    include('header.php'); 
    include('menu.php'); // Menu di bawah header
?>

<div class="dashboard">
    <div class="atas">
        <center><h1>Data Diri Alumni</h1></center>
    </div>

    <div class="content-detail" style="padding: 20px;">
        <p>Selamat Datang, **<?php echo htmlspecialchars($_SESSION['nama']); ?>**.</p>
        <p>Di sini akan ditampilkan informasi pribadi Anda (NIK, Jurusan, Alamat, dll.) yang diambil dari database.</p>
        </div>
    </div>

<?php
    include('footer.php');
?>