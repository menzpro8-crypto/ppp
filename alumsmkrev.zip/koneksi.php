<?php
// Informasi koneksi database
$servername = "sql209.infinityfree.com"; // Ganti dengan nama host Anda
$username = "if0_40886733"; // Ganti dengan nama pengguna database Anda
$password = "alumsmk111"; // Ganti dengan kata sandi database Anda
$dbname = "if0_40886733_alumsmk"; // Ganti dengan nama database Anda

// Membuat koneksi
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Memeriksa koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>