<?php
// hapus_alumni.php
session_start();
include('koneksi.php'); 

// Pengecekan Akses Admin
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); 
    exit;
}

$id_alumni = $_GET['id'] ?? 0;
$pesan = '';

if ($id_alumni) {
    // Query DELETE
    $sql_delete = "DELETE FROM alumni WHERE id = ?";
    
    // Siapkan dan eksekusi statement untuk mencegah SQL Injection
    $stmt = mysqli_prepare($conn, $sql_delete);
    mysqli_stmt_bind_param($stmt, "i", $id_alumni); 

    if (mysqli_stmt_execute($stmt)) {
        // Berhasil dihapus, redirect dengan pesan sukses
        $pesan = urlencode("Data alumni dengan ID #{$id_alumni} berhasil dihapus.");
        header("Location: kelola_alumni.php?pesan=sukses&msg={$pesan}");
    } else {
        // Gagal dihapus, redirect dengan pesan error
        $pesan = urlencode("Gagal menghapus data alumni: " . mysqli_error($conn));
        header("Location: kelola_alumni.php?pesan=gagal&msg={$pesan}");
    }
    mysqli_stmt_close($stmt);
} else {
    // ID tidak valid, redirect dengan pesan error
    $pesan = urlencode("ID Alumni tidak valid untuk dihapus.");
    header("Location: kelola_alumni.php?pesan=gagal&msg={$pesan}");
}

// Tutup koneksi dan pastikan tidak ada output lain
mysqli_close($conn); 
exit;
?>