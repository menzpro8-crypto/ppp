<?php
// proses_login.php
session_start();
include('koneksi.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $input_username = $_POST['username'];
    $input_password = $_POST['password'];
    $is_logged_in = false;
    $redirect_url = "login.php?error=1"; // Default error

    if (empty($input_username) || empty($input_password)) {
        header("Location: login.php?error=2");
        exit;
    }

    // =======================================================
    // 1. COBA LOGIN SEBAGAI ADMIN (Tabel: admin)
    // =======================================================
    $sql_admin = "SELECT username, nama_lengkap AS nama, password FROM admin WHERE username = ?"; 
    $stmt_admin = mysqli_prepare($conn, $sql_admin);
    mysqli_stmt_bind_param($stmt_admin, "s", $input_username);
    mysqli_stmt_execute($stmt_admin);
    $result_admin = mysqli_stmt_get_result($stmt_admin);

    if (mysqli_num_rows($result_admin) === 1) {
        $row = mysqli_fetch_assoc($result_admin);
        
        // Verifikasi Password Admin (Diasumsikan plain text)
        if ($input_password === $row['password']) {
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $row['username'];
            $_SESSION['nama'] = $row['nama'];
            $_SESSION['role'] = 'admin'; // Menetapkan Role Admin
            $redirect_url = "dashboard_logined.php"; 
            $is_logged_in = true;
        }
    }
    mysqli_stmt_close($stmt_admin);


    // =======================================================
    // 2. JIKA GAGAL SEBAGAI ADMIN, COBA LOGIN SEBAGAI ALUMNI (Tabel: alumni)
    // =======================================================
    if (!$is_logged_in) {
            // Cari alumni berdasarkan NISN atau nama sehingga kita mendapatkan kolom `nisn`.
            $sql_alumni = "SELECT nisn, nama, password FROM alumni WHERE nisn = ? OR nama = ? LIMIT 1";
            $stmt_alumni = mysqli_prepare($conn, $sql_alumni);
            mysqli_stmt_bind_param($stmt_alumni, "ss", $input_username, $input_username);
            mysqli_stmt_execute($stmt_alumni);
            $result_alumni = mysqli_stmt_get_result($stmt_alumni);

            if ($result_alumni && mysqli_num_rows($result_alumni) === 1) {
                $row = mysqli_fetch_assoc($result_alumni);

                // Verifikasi Password Alumni (Diasumsikan plain text)
                if ($input_password === $row['password']) {
                    $_SESSION['loggedin'] = true;
                    // Simpan NISN sebagai username sesi (dipakai di edit_bio.php)
                    $_SESSION['username'] = $row['nisn'];
                    $_SESSION['nama'] = $row['nama'];
                    $_SESSION['role'] = 'alumni';
                    $redirect_url = "dashboard_logined.php";
                    $is_logged_in = true;
                }
            }
            mysqli_stmt_close($stmt_alumni);
    }
    
    // =======================================================
    // 3. REDIRECT AKHIR
    // =======================================================
    header("Location: " . $redirect_url);
    exit;
} else {
    // Jika diakses tanpa POST request
    header("Location: login.php");
    exit;
}
?>