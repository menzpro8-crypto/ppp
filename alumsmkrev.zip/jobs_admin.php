<?php
// jobs_admin.php - Admin manage job postings
session_start();
include('koneksi.php');

// Akses hanya untuk admin
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: login.php');
    exit;
}

$pesan = '';
$editing = false;
$edit_job = null;
// Handle create
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    $title = trim($_POST['title'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $link = trim($_POST['link'] ?? '');
    $expire_date = trim($_POST['expire_date'] ?? '');

    if ($title === '') {
        $pesan = '<p class="error">Judul lowongan wajib diisi.</p>';
    } else {
        $sql = "INSERT INTO jobs (title, company, location, description, link, expire_date, posted_by) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        $admin_id = null; // optional: could map from admin table
        mysqli_stmt_bind_param($stmt, 'ssssssi', $title, $company, $location, $description, $link, $expire_date, $admin_id);
        if (mysqli_stmt_execute($stmt)) {
            $pesan = '<p class="success">Lowongan berhasil ditambahkan.</p>';
        } else {
            $pesan = '<p class="error">Gagal menambahkan lowongan: ' . mysqli_error($conn) . '</p>';
        }
        mysqli_stmt_close($stmt);
    }
}

// Handle delete via GET id
if (isset($_GET['delete_id'])) {
    $del_id = (int)$_GET['delete_id'];
    if ($del_id > 0) {
        $sql = "DELETE FROM jobs WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'i', $del_id);
        if (mysqli_stmt_execute($stmt)) {
            $pesan = '<p class="success">Lowongan berhasil dihapus.</p>';
        } else {
            $pesan = '<p class="error">Gagal menghapus lowongan: ' . mysqli_error($conn) . '</p>';
        }
        mysqli_stmt_close($stmt);
    }
}

// Handle delete via POST (preferred for actions)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $del_id = (int)($_POST['delete_id'] ?? 0);
    if ($del_id > 0) {
        $sql = "DELETE FROM jobs WHERE id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'i', $del_id);
        if (mysqli_stmt_execute($stmt)) {
            $pesan = '<p class="success">Lowongan berhasil dihapus.</p>';
        } else {
            $pesan = '<p class="error">Gagal menghapus lowongan: ' . mysqli_error($conn) . '</p>';
        }
        mysqli_stmt_close($stmt);
    }
}

// Handle edit form prefill (GET)
if (isset($_GET['edit_id'])) {
    $eid = (int)$_GET['edit_id'];
    if ($eid > 0) {
        $sql_e = "SELECT id, title, company, location, description, link, expire_date FROM jobs WHERE id = ? LIMIT 1";
        $stmt_e = mysqli_prepare($conn, $sql_e);
        if ($stmt_e) {
            mysqli_stmt_bind_param($stmt_e, 'i', $eid);
            mysqli_stmt_execute($stmt_e);
            $res_e = mysqli_stmt_get_result($stmt_e);
            if ($res_e && mysqli_num_rows($res_e) === 1) {
                $edit_job = mysqli_fetch_assoc($res_e);
                $editing = true;
            }
            mysqli_stmt_close($stmt_e);
        }
    }
}

// Handle update (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $id = (int)($_POST['id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $company = trim($_POST['company'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $link = trim($_POST['link'] ?? '');
    $expire_date = trim($_POST['expire_date'] ?? '');

    if ($id <= 0 || $title === '') {
        $pesan = '<p class="error">ID tidak valid atau Judul kosong.</p>';
    } else {
        $sql_up = "UPDATE jobs SET title = ?, company = ?, location = ?, description = ?, link = ?, expire_date = ? WHERE id = ?";
        $stmt_up = mysqli_prepare($conn, $sql_up);
        if ($stmt_up) {
            mysqli_stmt_bind_param($stmt_up, 'ssssssi', $title, $company, $location, $description, $link, $expire_date, $id);
            if (mysqli_stmt_execute($stmt_up)) {
                $pesan = '<p class="success">Lowongan berhasil diperbarui.</p>';
                // refresh jobs and clear edit state
                $editing = false;
                $edit_job = null;
            } else {
                $pesan = '<p class="error">Gagal memperbarui lowongan: ' . mysqli_error($conn) . '</p>';
            }
            mysqli_stmt_close($stmt_up);
        }
    }
}

// Ambil semua lowongan
$jobs = [];
$sql = "SELECT id, title, company, location, link, expire_date, created_at FROM jobs ORDER BY created_at DESC";
$res = mysqli_query($conn, $sql);
if ($res) {
    while ($row = mysqli_fetch_assoc($res)) $jobs[] = $row;
}

include('header.php');
include('menu.php');
?>

<style>
:root{--card:#ffffff;--muted:#6c757d;--accent:#4BA1CF;--success:#28a745;--danger:#dc3545}
body{background:#f4f6f8}
.container{max-width:1100px;margin:24px auto;padding:22px;background:transparent}
.card{background:var(--card);border-radius:10px;padding:18px;box-shadow:0 6px 18px rgba(31,45,61,0.06)}
.grid{display:grid;grid-template-columns:1fr 1.4fr;gap:20px}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.form-group{margin-bottom:12px}
.form-group label{display:block;font-weight:600;color:#333;margin-bottom:6px;font-size:14px}
.form-group input[type=text],.form-group input[type=date],.form-group textarea{width:100%;padding:10px;border:1px solid #e3e6ea;border-radius:8px;font-size:14px;box-sizing:border-box}
.form-group input[type=text]:focus, .form-group input[type=date]:focus, .form-group textarea:focus{outline:none;border-color:var(--accent);box-shadow:0 4px 12px rgba(75,161,207,0.12)}
.form-group textarea{min-height:140px;resize:vertical}
.actions{display:flex;gap:8px;align-items:center;margin-top:8px;justify-content:flex-start}
.btn{display:inline-block;padding:10px 14px;border-radius:8px;color:#fff;text-decoration:none;border:none;cursor:pointer;font-weight:700;transition:transform .08s ease, box-shadow .08s ease}
.btn:hover{transform:translateY(-1px);box-shadow:0 6px 12px rgba(15,40,80,0.06)}
.btn-primary{background:var(--accent)}
.btn-ghost{background:#6c757d}
.btn-danger{background:var(--danger)}
.msg{margin-bottom:12px}
.msg.success{background:#d4edda;color:#155724;padding:10px;border-radius:8px}
.msg.error{background:#f8d7da;color:#721c24;padding:10px;border-radius:8px}
.jobs-table{width:100%;border-collapse:collapse;margin-top:6px}
.jobs-table thead th{background:#f7fafc;text-align:left;padding:12px;border-bottom:1px solid #eef2f6;color:#344052}
.jobs-table tbody td{padding:12px;border-bottom:1px solid #f1f5f9;vertical-align:top}
.jobs-table td, .jobs-table th{word-break:break-word}
.job-title{font-weight:700;color:#16325c}
.meta{color:var(--muted);font-size:13px}
.row-actions{display:flex;gap:8px;align-items:center}
.row-actions a, .row-actions button{margin:0;text-decoration:none;color:#fff;padding:8px 10px;border-radius:8px;font-weight:700;display:inline-block;border:none;cursor:pointer}
.row-actions a.edit, .row-actions button.edit{background:#007bff}
.row-actions a.del, .row-actions button.del{background:var(--danger)}
.row-actions form{margin:0}
@media (max-width:900px){.grid{grid-template-columns:1fr;}.form-row{grid-template-columns:1fr}}
@media (max-width:600px){
    .actions{flex-direction:column;align-items:stretch}
    .actions .btn{width:100%}
}
</style>

<div class="container">
    <div class="card">
        <h2 style="margin:0 0 12px 0;color:#16325c">Kelola Lowongan Kerja</h2>
        <?php if(!empty($pesan)): ?>
            <div class="msg <?php echo strpos($pesan,'success')!==false? 'success':'error'; ?>"><?php echo $pesan; ?></div>
        <?php endif; ?>

        <div class="grid">
            <div>
                <div class="card" style="padding:14px">
                    <h3 style="margin-top:0;color:#16325c"><?php echo $editing ? 'Edit Lowongan' : 'Tambah Lowongan Baru'; ?></h3>
                    <form method="POST">
                        <?php if ($editing): ?>
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="id" value="<?php echo htmlspecialchars($edit_job['id']); ?>">
                        <?php else: ?>
                            <input type="hidden" name="action" value="create">
                        <?php endif; ?>

                        <div class="form-row">
                            <div class="form-group">
                                <label>Judul <span style="color:var(--danger)">*</span></label>
                                <input type="text" name="title" maxlength="255" placeholder="Contoh: Junior Web Developer" required value="<?php echo $editing ? htmlspecialchars($edit_job['title']) : ''; ?>">
                            </div>
                            <div class="form-group">
                                <label>Perusahaan</label>
                                <input type="text" name="company" maxlength="255" placeholder="Nama perusahaan" value="<?php echo $editing ? htmlspecialchars($edit_job['company']) : ''; ?>">
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label>Lokasi</label>
                                <input type="text" name="location" maxlength="255" placeholder="Kota/Kabupaten atau Remote" value="<?php echo $editing ? htmlspecialchars($edit_job['location']) : ''; ?>">
                            </div>
                            <div class="form-group">
                                <label>Tanggal Kadaluarsa</label>
                                <input type="date" name="expire_date" value="<?php echo $editing ? htmlspecialchars($edit_job['expire_date']) : ''; ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Link (opsional)</label>
                            <input type="text" name="link" maxlength="512" placeholder="https://example.com/apply" value="<?php echo $editing ? htmlspecialchars($edit_job['link']) : ''; ?>">
                        </div>

                        <div class="form-group">
                            <label>Deskripsi</label>
                            <textarea name="description" placeholder="Rincian tugas, kualifikasi, cara melamar..."><?php echo $editing ? htmlspecialchars($edit_job['description']) : ''; ?></textarea>
                        </div>

                        <div class="actions">
                            <button class="btn btn-primary" type="submit"><?php echo $editing ? 'Simpan Perubahan' : 'Tambah Lowongan'; ?></button>
                            <?php if ($editing): ?>
                                <button type="button" class="btn btn-ghost" onclick="window.location='jobs_admin.php'">Batal</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>

            <div>
                <div class="card" style="padding:14px">
                    <h3 style="margin-top:0;color:#16325c">Daftar Lowongan</h3>
                    <?php if (empty($jobs)): ?>
                        <p style="color:var(--muted)">Tidak ada lowongan saat ini.</p>
                    <?php else: ?>
                        <table class="jobs-table">
                            <thead>
                                <tr><th>Judul</th><th>Perusahaan / Lokasi</th><th>Expire</th><th>Aksi</th></tr>
                            </thead>
                            <tbody>
                                <?php foreach ($jobs as $j): ?>
                                    <tr>
                                        <td>
                                            <div class="job-title"><?php echo htmlspecialchars($j['title']); ?></div>
                                            <div class="meta">Diposting: <?php echo htmlspecialchars(date('Y-m-d', strtotime($j['created_at']))); ?></div>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($j['company'] ?: '-'); ?><br>
                                            <span class="meta"><?php echo htmlspecialchars($j['location'] ?: '-'); ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($j['expire_date'] ?? '-'); ?></td>
                                        <td class="row-actions">
                                            <a class="edit" href="jobs_admin.php?edit_id=<?php echo $j['id']; ?>">Edit</a>
                                            <a class="del" href="jobs_admin.php?delete_id=<?php echo $j['id']; ?>" onclick="return confirm('Hapus lowongan ini?')">Hapus</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); mysqli_close($conn); ?>
