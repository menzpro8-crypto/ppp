<?php
// export_vcard.php
session_start();
include('koneksi.php');

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || ($_SESSION['role'] ?? '') !== 'alumni') {
    header('Location: login.php');
    exit;
}

$nisn = $_SESSION['username'];
$sql = "SELECT nama, nisn, jurusan, tahun_lulus, no_hp, email, alamat FROM alumni WHERE nisn = ? LIMIT 1";
$stmt = mysqli_prepare($conn, $sql);
if (!$stmt) {
    die('Unable to prepare statement');
}
mysqli_stmt_bind_param($stmt, 's', $nisn);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
if (!$res || mysqli_num_rows($res) !== 1) {
    mysqli_stmt_close($stmt);
    die('Data alumni tidak ditemukan');
}
$al = mysqli_fetch_assoc($res);
mysqli_stmt_close($stmt);

$fullname = $al['nama'];
$tel = $al['no_hp'];
$email = $al['email'];
$org = $al['jurusan'];
$note = 'Tahun Lulus: ' . ($al['tahun_lulus'] ?? '');
$adr = $al['alamat'];

$vcard = "BEGIN:VCARD\nVERSION:3.0\n";
$vcard .= "FN:" . addslashes($fullname) . "\n";
$vcard .= "N:;" . addslashes($fullname) . ";;;\n";
if (!empty($org)) $vcard .= "ORG:" . addslashes($org) . "\n";
if (!empty($tel)) $vcard .= "TEL;TYPE=CELL:" . addslashes($tel) . "\n";
if (!empty($email)) $vcard .= "EMAIL;TYPE=INTERNET:" . addslashes($email) . "\n";
if (!empty($adr)) $vcard .= "ADR;TYPE=HOME:;;" . addslashes($adr) . ";;;;\n";
$vcard .= "NOTE:" . addslashes($note) . "\n";
$vcard .= "END:VCARD\n";

$filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', $fullname) ?: 'alumni_' . $nisn;
header('Content-Type: text/vcard; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '.vcf"');
echo $vcard;
exit;
?>