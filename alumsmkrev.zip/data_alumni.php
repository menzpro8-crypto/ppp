<?php
// data_alumni.php
// Pastikan koneksi.php sudah di-include
include('koneksi.php');

// =========================================================================
// 1. QUERY UNTUK KPI DAN GRAFIK PIE/DOUGHNUT (TOTAL & STATUS SAAT INI)
// =========================================================================

// Menghitung total dan status per kategori (Bekerja, Kuliah, dll.)
$query_status = "
    SELECT 
        status_saat_ini, 
        COUNT(id) AS jumlah 
    FROM 
        alumni 
    GROUP BY 
        status_saat_ini
";

$result_status = mysqli_query($conn, $query_status);

// Inisialisasi variabel KPI
$total_alumni = 0;
$total_bekerja = 0;
$total_kuliah = 0;
$total_lainnya = 0; 

// Inisialisasi variabel untuk Grafik Pie/Doughnut
$labels_pie = [];
$data_values_pie = [];

// Warna standar untuk chart (bisa diubah)
$colors_pie = [
    'rgba(255, 99, 132, 0.8)', // Merah
    'rgba(54, 162, 235, 0.8)', // Biru
    'rgba(255, 206, 86, 0.8)', // Kuning
    'rgba(75, 192, 192, 0.8)', // Hijau
];
$colors_pie_final = [];
$color_index = 0;

// Memproses hasil query status
if ($result_status && mysqli_num_rows($result_status) > 0) {
    while ($row = mysqli_fetch_assoc($result_status)) {
        $status = $row['status_saat_ini'];
        $jumlah = (int)$row['jumlah'];
        $total_alumni += $jumlah; 

        // Mengisi data Pie Chart
        $labels_pie[] = $status;
        $data_values_pie[] = $jumlah;
        
        // Memastikan warna tidak out of bounds
        $colors_pie_final[] = $colors_pie[$color_index % count($colors_pie)];
        $color_index++;

        
        $status_lower = strtolower($status);
        
        if (strpos($status_lower, 'bekerja') !== false || strpos($status_lower, 'wiraswasta') !== false) {
            // Jika status mengandung 'bekerja' atau 'wiraswasta', masukkan ke kategori Bekerja
            $total_bekerja += $jumlah;
        } elseif (strpos($status_lower, 'kuliah') !== false || strpos($status_lower, 'studi') !== false) {
            // Jika status mengandung 'kuliah' atau 'studi', masukkan ke kategori Kuliah
            $total_kuliah += $jumlah;
        } 
        
       

        // Mengingat nilai ENUM yang kita gunakan di `edit_bio.php` sebelumnya:
        // $options = ['Bekerja', 'Lanjut Kuliah', 'Wiraswasta', 'Menganggur/Mencari Kerja'];
        
        if ($status === 'Bekerja') {
            $total_bekerja += $jumlah;
        } elseif ($status === 'Lanjut Kuliah') {
            $total_kuliah += $jumlah;
        } elseif ($status === 'Wiraswasta' || $status === 'Menganggur/Mencari Kerja') {
            $total_lainnya += $jumlah;
        }
        
    } 
    
    $total_bekerja = 0;
    $total_kuliah = 0;
    
    mysqli_data_seek($result_status, 0); // Reset pointer result
    
    while ($row = mysqli_fetch_assoc($result_status)) {
        $status = $row['status_saat_ini'];
        $jumlah = (int)$row['jumlah'];
        $status_lower = strtolower($status);
        
        if (strpos($status_lower, 'bekerja') !== false) {
            $total_bekerja += $jumlah;
        } elseif (strpos($status_lower, 'kuliah') !== false) {
            $total_kuliah += $jumlah;
        } 
    }
    
    // Hitung total lainnya berdasarkan data yang sudah ditarik
    $total_lainnya = $total_alumni - $total_bekerja - $total_kuliah;
    
} else {
    // Handle jika tidak ada data sama sekali
    $total_alumni = 0;
    $total_bekerja = 0;
    $total_kuliah = 0;
    $total_lainnya = 0;
}


// =========================================================================
// 2. QUERY UNTUK GRAFIK BATANG (JUMLAH ALUMNI PER TAHUN KELULUSAN)
// =========================================================================

$query_tahun = "
    SELECT 
        tahun_lulus, 
        COUNT(id) AS jumlah_alumni 
    FROM 
        alumni 
    GROUP BY 
        tahun_lulus 
    ORDER BY 
        tahun_lulus ASC
";

$result_tahun = mysqli_query($conn, $query_tahun);

// Inisialisasi variabel untuk Grafik Batang
$tahun_labels_bar = [];
$jumlah_alumni_bar = [];

if ($result_tahun && mysqli_num_rows($result_tahun) > 0) {
    while ($row = mysqli_fetch_assoc($result_tahun)) {
        $tahun_labels_bar[] = $row['tahun_lulus'];
        $jumlah_alumni_bar[] = (int)$row['jumlah_alumni'];
    }
}


// =========================================================================
// 3. QUERY UNTUK TABEL ALUMNI TERBARU
// =========================================================================

$query_terbaru = "
    SELECT 
        nama, 
        tahun_lulus, 
        status_saat_ini
    FROM 
        alumni
    ORDER BY 
        id DESC
    LIMIT 5
"; 

$result_terbaru = mysqli_query($conn, $query_terbaru);
$alumni_terbaru = [];

if ($result_terbaru) {
    while ($row = mysqli_fetch_assoc($result_terbaru)) {
        $alumni_terbaru[] = $row;
    }
}

// Koneksi tidak ditutup, karena akan digunakan oleh file induk
?>