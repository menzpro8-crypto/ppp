<?php
// edit_alumni.php
session_start();
include('koneksi.php'); 
include('header.php');
include('menu.php');

// Pengecekan Akses Admin
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); 
    exit;
}

$id_alumni = $_GET['id'] ?? 0;
$pesan = '';

// Array untuk ENUM yang baru
$status_options = ['Bekerja', 'Kuliah', 'Lainnya'];
$jurusan_options = ['RPL', 'MM', 'OTO', 'MESIN'];

// =======================================================
// 1. PROSES UPDATE DATA (POST REQUEST)
// =======================================================
if ($_SERVER["REQUEST_METHOD"] == "POST" && $id_alumni) {
    // Ambil data dari form
    $nama = $_POST['nama'];
    $tahun_lulus = $_POST['tahun_lulus'];
    $jurusan = $_POST['jurusan'];
    $no_hp = $_POST['no_hp'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $status_saat_ini = $_POST['status_saat_ini'];
    
    // Inisialisasi parameter SQL
    $password_update = "";
    $params = [];
    $types = "";

    // Cek jika password diisi (opsional)
    if (!empty($_POST['password'])) {
        $password_input = $_POST['password']; 
        $password_update = ", password = ?";
        $params[] = $password_input;
        $types .= "s";
    }

    // Query UPDATE
    $sql_update = "UPDATE alumni 
                   SET nama = ?, tahun_lulus = ?, jurusan = ?, no_hp = ?, email = ?, alamat = ?, status_saat_ini = ? {$password_update} 
                   WHERE id = ?";
    
    // Siapkan parameter utama
    $params = array_merge([$nama, $tahun_lulus, $jurusan, $no_hp, $email, $alamat, $status_saat_ini], $params);
    $params[] = $id_alumni;
    
    // Tipe data untuk binding: sssssss (7 string) + tipe password (jika ada) + i (integer id)
    $types = "sssssss" . $types . "i"; 
    
    // Siapkan dan eksekusi statement
    $stmt = mysqli_prepare($conn, $sql_update);
    // Note: Anda harus menggunakan operator splat (...) untuk unpack array $params ke mysqli_stmt_bind_param
    mysqli_stmt_bind_param($stmt, $types, ...$params); 

    if (mysqli_stmt_execute($stmt)) {
        $pesan = "<p class='success'>Data alumni berhasil diperbarui!</p>";
    } else {
        $pesan = "<p class='error'>Gagal memperbarui data: " . mysqli_error($conn) . "</p>";
    }
    mysqli_stmt_close($stmt);
}


// =======================================================
// 2. AMBIL DATA ALUMNI UNTUK DITAMPILKAN DI FORM (RE-FETCH jika habis update)
// =======================================================
$alumni_data = [];
if ($id_alumni) {
    $sql_select = "SELECT * FROM alumni WHERE id = ?";
    $stmt_select = mysqli_prepare($conn, $sql_select);
    mysqli_stmt_bind_param($stmt_select, "i", $id_alumni);
    mysqli_stmt_execute($stmt_select);
    $result_select = mysqli_stmt_get_result($stmt_select);
    
    if (mysqli_num_rows($result_select) === 1) {
        $alumni_data = mysqli_fetch_assoc($result_select);
    } else {
        $pesan = "<p class='error'>Data alumni dengan ID #{$id_alumni} tidak ditemukan.</p>";
    }
    mysqli_stmt_close($stmt_select);
}

if (!$id_alumni || empty($alumni_data)) {
    if (empty($pesan)) $pesan = "<p class='error'>ID Alumni tidak valid.</p>";
}

?>

<style>
/* Gaya CSS untuk Form Edit */
.edit-container {
    max-width: 600px;
    margin: 20px auto;
    padding: 30px;
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

/* ... (Sertakan gaya CSS dari kelola_alumni.php untuk konsistensi, terutama .error dan .success) ... */
.edit-container h2 {
    color: #4BA1CF;
    border-bottom: 2px solid #eee;
    padding-bottom: 10px;
    margin-bottom: 20px;
    text-align: center;
}

.edit-container label {
    display: block;
    margin-top: 15px;
    margin-bottom: 5px;
    font-weight: bold;
    color: #333;
}

.edit-container input[type="text"],
.edit-container input[type="password"],
.edit-container input[type="email"],
.edit-container select,
.edit-container textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box; 
    font-size: 16px;
}

.edit-container textarea {
    resize: vertical;
    min-height: 80px;
}

.edit-container button {
    width: 100%;
    padding: 12px;
    background-color: #28a745; 
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    transition: background-color 0.3s;
    margin-top: 20px;
}

.edit-container button:hover {
    background-color: #1e7e34;
}

.error, .success {
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 5px;
    text-align: center;
    font-weight: bold;
}

.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}
</style>

<div class="edit-container">
    <h2>Edit Data Alumni</h2>

    <?php echo $pesan; ?>

    <?php if (!empty($alumni_data)): ?>
    <form action="edit_alumni.php?id=<?php echo htmlspecialchars($id_alumni); ?>" method="POST">
        
        <label for="nama">Nama Lengkap:</label>
        <input type="text" id="nama" name="nama" value="<?php echo htmlspecialchars($alumni_data['nama'] ?? ''); ?>" required>

        <label for="password">Ganti Password (Kosongkan jika tidak ingin ganti):</label>
        <input type="password" id="password" name="password" placeholder="Password Baru">
        
        <label for="tahun_lulus">Tahun Lulus:</label>
        <input type="text" id="tahun_lulus" name="tahun_lulus" value="<?php echo htmlspecialchars($alumni_data['tahun_lulus'] ?? ''); ?>" required>
        
        <label for="jurusan">Jurusan:</label>
        <select id="jurusan" name="jurusan" required>
            <?php foreach ($jurusan_options as $option): ?>
                <option value="<?php echo $option; ?>" 
                    <?php echo (isset($alumni_data['jurusan']) && $alumni_data['jurusan'] == $option) ? 'selected' : ''; ?>>
                    <?php echo $option; ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="no_hp">Nomor HP:</label>
        <input type="text" id="no_hp" name="no_hp" value="<?php echo htmlspecialchars($alumni_data['no_hp'] ?? ''); ?>">

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($alumni_data['email'] ?? ''); ?>">
        
        <label for="alamat">Alamat:</label>
        <textarea id="alamat" name="alamat"><?php echo htmlspecialchars($alumni_data['alamat'] ?? ''); ?></textarea>
        
        <label for="status_saat_ini">Status Saat Ini:</label>
        <select id="status_saat_ini" name="status_saat_ini" required>
            <?php foreach ($status_options as $option): ?>
                <option value="<?php echo $option; ?>" 
                    <?php echo (isset($alumni_data['status_saat_ini']) && $alumni_data['status_saat_ini'] == $option) ? 'selected' : ''; ?>>
                    <?php echo $option; ?>
                </option>
            <?php endforeach; ?>
        </select>
        
        <button type="submit">Simpan Perubahan</button>
    </form>
    <?php endif; ?>
    
    <div style="margin-top: 20px; text-align: center;">
        <a href="kelola_alumni.php" style="color: #4BA1CF; text-decoration: none; font-weight: bold;">← Kembali ke Kelola Alumni</a>
    </div>

</div>

<?php
include('footer.php');
mysqli_close($conn); 
?>