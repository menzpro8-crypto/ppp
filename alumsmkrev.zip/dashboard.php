<?php
// dashboard.php (Dashboard Publik)
session_start();
include('data_alumni.php'); // Ambil semua data statistik
include('header.php'); // Header (tanpa menu navigasi di bawahnya)
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<style>
    /* Variabel Warna & Estetika Dasar */
    :root {
        --primary-color: #4BA1CF; /* Warna Biru Tema dari Header */
        --bg-color: #f5f7fa;
        --card-bg: #ffffff;
        --text-dark: #2b2d42;
        --text-muted: #8d99ae;
        --shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        --radius: 10px;
    }

    body {
        background-color: var(--bg-color);
        font-family: Arial, sans-serif;
    }

    .dashboard-container {
        max-width: 1200px;
        margin: 20px auto;
        padding: 0 20px;
    }
    
    .dashboard-header {
        text-align: left;
        margin-bottom: 30px;
        border-bottom: 2px solid #eee;
        padding-bottom: 15px;
    }

    .dashboard-header h1 {
        font-size: 28px;
        color: var(--primary-color);
        margin: 0;
    }

    .kpi-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .kpi-card {
        background-color: var(--card-bg);
        padding: 20px;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        text-align: center;
        transition: transform 0.3s;
    }

    .kpi-card:hover {
        transform: translateY(-5px);
    }

    .kpi-card h2 {
        font-size: 32px;
        color: var(--primary-color);
        margin: 0 0 5px 0;
    }

    .kpi-card p {
        color: var(--text-muted);
        margin: 0;
        font-weight: 600;
        font-size: 14px;
    }

    /* Area Chart & Data Terbaru */
    .content-area {
        display: flex;
        gap: 20px;
    }

    .chart-box {
        background-color: var(--card-bg);
        padding: 20px;
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        margin-bottom: 20px;
        flex: 1; /* Agar fleksibel */
    }
    
    .chart-box h3 {
        color: var(--text-dark);
        border-bottom: 1px solid #eee;
        padding-bottom: 10px;
        margin-bottom: 20px;
        font-size: 18px;
    }

    .chart-half {
        flex: 1;
        max-width: 50%;
    }

    .chart-container {
        height: 350px;
        width: 100%;
        display: flex; /* Untuk menengahkan canvas */
        justify-content: center;
        align-items: center;
    }
    
    .data-terbaru-box {
        background-color: var(--card-bg);
        border-radius: var(--radius);
        box-shadow: var(--shadow);
        width: 100%;
        max-width: 400px; /* Lebar maksimum untuk sidebar */
    }

    .data-terbaru-box table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
    }

    .data-terbaru-box th, .data-terbaru-box td {
        padding: 10px 0;
        text-align: left;
        border-bottom: 1px solid #eee;
    }
    
    .data-terbaru-box th {
        color: var(--primary-color);
        font-weight: 700;
        background-color: #f7f7f7;
    }
    
    .data-terbaru-box td:last-child {
        font-weight: 600;
        color: #008000; /* Warna Hijau untuk status */
    }

    /* Responsif */
    @media (max-width: 900px) {
        .content-area {
            flex-direction: column;
        }
        .chart-half, .data-terbaru-box {
            max-width: 100%;
        }
    }
    
    .login-info {
        background-color: #ffeaa7; 
        padding: 15px;
        border-radius: var(--radius);
        margin-bottom: 20px;
        text-align: center;
        font-weight: 600;
        color: #333;
        border: 1px solid #fdcb6e;
    }
    .login-info a {
        color: var(--primary-color);
        font-weight: bold;
        text-decoration: none;
    }
    .login-info a:hover {
        text-decoration: underline;
    }
</style>

<div class="dashboard-container">
    
    <div class="login-info">
        Ini adalah Dashboard Publik. Untuk mengelola data diri dan akses fitur Admin, silakan <a href="login.php">LOGIN</a>.
    </div>
    
    <div class="dashboard-header">
        <h1>Dashboard Monitoring Alumni</h1>
        <p>Statistik dan informasi umum lulusan SMK AL-BASTHOMI</p>
    </div>

    <div class="kpi-cards">
        <div class="kpi-card">
            <h2><?php echo number_format($total_alumni); ?></h2>
            <p>Total Alumni Terdaftar</p>
        </div>
        <div class="kpi-card">
            <h2><?php echo number_format($total_bekerja); ?></h2>
            <p>Sedang Bekerja</p>
        </div>
        <div class="kpi-card">
            <h2><?php echo number_format($total_kuliah); ?></h2>
            <p>Lanjut Kuliah</p>
        </div>
        <div class="kpi-card">
            <h2><?php echo number_format($total_lainnya); ?></h2>
            <p>Wiraswasta/Lainnya</p>
        </div>
    </div>
    
    <div class="content-area">
        
        <div class="chart-half">
            <div class="chart-box">
                <h3>Persentase Status Alumni Saat Ini</h3>
                <div class="chart-container">
                    <canvas id="alumniPieChart"></canvas>
                </div>
            </div>
            
            <div class="chart-box">
                <h3>Jumlah Alumni Berdasarkan Tahun Lulus</h3>
                <div class="chart-container">
                    <canvas id="alumniBarChart"></canvas>
                </div>
            </div>
        </div>
        
        <div class="data-terbaru-box">
            <h3>5 Data Alumni Terbaru</h3>
            <?php if (!empty($alumni_terbaru)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>Lulus</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($alumni_terbaru as $alumni): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($alumni['nama']); ?></td>
                        <td><?php echo htmlspecialchars($alumni['tahun_lulus']); ?></td>
                        <td><?php echo htmlspecialchars($alumni['status_saat_ini']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p>Belum ada data alumni yang tercatat.</p>
            <?php endif; ?>
        </div>
        
    </div> </div> <script>
    // Pastikan data tersedia dari data_alumni.php
    const labelsPie = <?php echo json_encode($labels_pie); ?>;
    const dataValuesPie = <?php echo json_encode($data_values_pie); ?>;
    const colorsPie = <?php echo json_encode($colors_pie_final); ?>; // Menggunakan variabel warna baru dari data_alumni.php
    
    // --- 1. Grafik Pie --
    const dataPie = {
        labels: labelsPie,
        datasets: [{
            data: dataValuesPie,
            backgroundColor: colorsPie,
            hoverOffset: 4
        }]
    };

    const configPie = {
        type: 'doughnut',
        data: dataPie,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '60%', // Lubang Doughnut
            plugins: {
                title: { display: false },
                legend: { position: 'bottom' },
            }
        }
    };

    new Chart(document.getElementById('alumniPieChart'), configPie);


    // --- 2. Grafik Batang (Bar Chart) ---
    const labelsBar = <?php echo json_encode($tahun_labels_bar); ?>;
    const dataValuesBar = <?php echo json_encode($jumlah_alumni_bar); ?>;
    const singleColorBar = 'rgba(67, 97, 238, 0.8)'; // Biru

    const configBar = {
        type: 'bar',
        data: {
            labels: labelsBar,
            datasets: [{
                label: 'Jumlah Alumni',
                data: dataValuesBar,
                backgroundColor: singleColorBar,
                borderColor: singleColorBar.replace('0.8', '1'),
                borderWidth: 1,
                borderRadius: 5 // Sudut tumpul
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, grid: { color: '#f0f0f0' } },
                x: { grid: { display: false } }
            },
            plugins: {
                title: { display: false },
                legend: { display: false } // Sembunyikan legend karena hanya 1 data series
            }
        }
    };

    new Chart(document.getElementById('alumniBarChart'), configBar);
</script>


<?php include('footer.php'); ?>